# franka
Franka panda mujoco models


# Environment

franka_panda.xml           |  comming soon
:-------------------------:|:-------------------------:
![Alt text](franka_panda.png?raw=false "sawyer") |  comming soon
