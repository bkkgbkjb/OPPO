# D'Suite Scenes

This repository is based on a collection of [MuJoCo](http://www.mujoco.org/) simulation
scenes and common assets for D'Suite environments. Based on code in the ROBEL suite 
https://github.com/google-research/robel

## Disclaimer

This is not an official Google product.

